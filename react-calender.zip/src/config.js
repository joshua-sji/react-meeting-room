export const 
  GOOGLE_API_KEY = 'AIzaSyAb_Zr5U3IfOkA4m5GXghN9-V6mY7b0iLs',
  CALENDAR_ID_BIG = 'emn7rmeovk782djag1bsmqnq9o@group.calendar.google.com',
  CALENDAR_ID_SMALL = 'tl60n85uhbal4711uhrft44sac@group.calendar.google.com';